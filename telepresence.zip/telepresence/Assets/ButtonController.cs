﻿using System.Collections;
using System.Collections.Generic;
using UnityEngine;
using UnityEngine.SceneManagement;

public class ButtonController : MonoBehaviour
{
    public void QuitGame()
    {
        print("Working");
        Application.Quit();
    }
    public void StartOculus()
    {
        print("Starting");
        SceneManager.LoadScene(1);
    }
	
}
