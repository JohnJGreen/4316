﻿
print("Trying");
function QuitProgram() {
    print("Hello there");
	Application.Quit();
	print("Hi");
}
function StartOculus(){
	Application.LoadScene(1);
}
